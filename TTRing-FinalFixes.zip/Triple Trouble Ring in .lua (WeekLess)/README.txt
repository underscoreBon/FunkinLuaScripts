T̲r̲i̲p̲l̲e̲ T̲r̲o̲u̲b̲l̲e̲ R̲i̲n̲g̲ R̲e̲c̲r̲e̲a̲t̲e̲d̲ i̲n̲ .̲L̲u̲a̲

"The thing that nobody wanted to do..."

\\CREDITS://
(https://gamebanana.com/tools/8780) heat_ on GB - TGT Crosshair Script for Template (TYSM!!!!)
Sonic.exe Mod - Sprites 
n_bonnie2 - Script Creator, pixel ring sprites

How this Works:
Basicly its a notetype that:
1. is always an dad left note (note 0)
2. is "offseted" so it's visually correct (1.2 Update)
3. Has no NoteSplash or rating, ITS A RING NOTE IDOIT
4. Can only be hit by pressing [SPACE]
5. LONGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG NOTES.

Feel Free to improve and use in your mods, BUT CREDIT THE PEOPLE/MODS USED

here's my discord because yes n_bonnie2#7150

look in the "ring.lua" script if ya want how i do this

Added swap strums lmao

(Note: Yes, this was usd in THAT Fanmade D-Sides Sonic.Exe)


also there are some mods in the ring script... so get after it

(also the strum ring's tag is "strumring", use setProperty('strumring.x', [VALUE]) or smth.)